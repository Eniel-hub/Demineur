/*
Deminer Game
* July 16, 2024
* author: Eniel Leba
* tableau[row][col]
*/
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to Demineur");
        System.out.println("enter the level you would like to play (easy, medium, hard): ");
        Level level = switch (scanner.nextLine().toUpperCase()){
            case "HARD" -> level = Level.HARD;
            case "MEDIUM" -> level = Level.MEDIUM;
            default -> level = Level.EASY;
        };
        Game game = new Game(level);
        System.out.println("New game level: "+level);
        game.play();
    }
}